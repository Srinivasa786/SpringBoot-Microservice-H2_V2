package com.sync.poc.exchange.rates.service;

import java.util.List;

import com.sync.poc.exchange.rates.domain.ExchangeRates;

public interface ExchangeRatesService {
	public ExchangeRates createExchangeRates(ExchangeRates exchangeRates);

	List<ExchangeRates> getByDates(String startDate);

	ExchangeRates getGPB(String startDate);
}
