package com.sync.poc.exchange.rates.transform;

import com.sync.poc.exchange.rates.domain.ExchangeRates;
import com.sync.poc.exchange.rates.model.ExchangeRatesInfo;
import com.sync.poc.exchange.rates.model.ExchangeRatesType;
import com.sync.poc.exchange.rates.model.Rates;

public class ExchangeRatesTransform {

	public static ExchangeRates getExchangeRates(ExchangeRatesInfo ratesInfo) {
		ExchangeRates exchangeRates = new ExchangeRates();
		exchangeRates.setDate(ratesInfo.getDate());
		Rates rates = ratesInfo.getRates();
		exchangeRates.setHKD(rates.getHKD());
		exchangeRates.setGBP(rates.getGBP());
		exchangeRates.setUSD(rates.getUSD());

		return exchangeRates;
	}

	public static ExchangeRatesType getExchangeRatesType(ExchangeRates exchangeRates) {
		ExchangeRatesType exchangeRatesType = new ExchangeRatesType();
		exchangeRatesType.setId(exchangeRates.getId());
		exchangeRatesType.setDate(exchangeRates.getDate());
		exchangeRatesType.setHKD(exchangeRates.getHKD());
		exchangeRatesType.setGBP(exchangeRates.getGBP());
		exchangeRatesType.setUSD(exchangeRates.getUSD());

		return exchangeRatesType;
	}
}
