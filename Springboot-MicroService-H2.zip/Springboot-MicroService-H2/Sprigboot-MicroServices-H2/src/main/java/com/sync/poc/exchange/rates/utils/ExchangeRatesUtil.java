package com.sync.poc.exchange.rates.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ExchangeRatesUtil {

	public static Date todayDate() {

		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String dateString = dateFormat.format(date);
		Date result = null;
		try {
			result = new SimpleDateFormat("yyyy-MM-dd").parse(dateString);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return result;
	}

	public static List<String> getDates() {
		List<String> dates = new ArrayList<>();

		dates.add("2020-08-01");
		dates.add("2020-07-01");
		dates.add("2020-06-01");
		dates.add("2020-05-01");
		dates.add("2020-04-01");
		dates.add("2020-03-01");
		dates.add("2020-02-01");
		dates.add("2020-01-01");

		dates.add("2019-12-01");
		dates.add("2019-11-01");
		dates.add("2019-10-01");
		dates.add("2019-09-01");

		return dates;

	}

	public static Date convertStringToDate(String date) {

		Date result = null;
		try {
			result = new SimpleDateFormat("yyyy-MM-dd").parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return result;

	}

}
