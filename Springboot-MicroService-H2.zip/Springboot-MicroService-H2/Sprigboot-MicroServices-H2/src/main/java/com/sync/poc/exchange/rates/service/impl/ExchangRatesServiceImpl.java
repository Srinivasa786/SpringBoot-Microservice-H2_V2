package com.sync.poc.exchange.rates.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sync.poc.exchange.rates.domain.ExchangeRates;
import com.sync.poc.exchange.rates.repository.ExchangeRatesRepository;
import com.sync.poc.exchange.rates.service.ExchangeRatesService;
import com.sync.poc.exchange.rates.utils.ExchangeRatesUtil;

@Service
public class ExchangRatesServiceImpl implements ExchangeRatesService {

	@Autowired
	ExchangeRatesRepository exchangeRatesRepository;

	@SuppressWarnings("unused")
	@Override
	public ExchangeRates createExchangeRates(ExchangeRates exchangeRates) {
		ExchangeRates result = exchangeRatesRepository.save(exchangeRates);
		return result;
	}

	@Override
	public List<ExchangeRates> getByDates(String date){
		Date startDate = ExchangeRatesUtil.convertStringToDate(date);
		Date todayDate = ExchangeRatesUtil.todayDate();
		List<ExchangeRates> result = exchangeRatesRepository.findAllByDateBetween(startDate, todayDate);
		return result;
	}

	@Override
	public ExchangeRates getGPB(String date) {
		Date dateResult = ExchangeRatesUtil.convertStringToDate(date);
		ExchangeRates exchangeRates = exchangeRatesRepository.findByDate(dateResult);
		return exchangeRates;
	}
}
