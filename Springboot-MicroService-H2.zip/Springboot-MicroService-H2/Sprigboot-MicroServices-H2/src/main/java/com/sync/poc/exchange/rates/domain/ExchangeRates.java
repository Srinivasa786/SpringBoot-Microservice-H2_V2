package com.sync.poc.exchange.rates.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "EXCHANGE_RATES")
public class ExchangeRates {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "EXCHANGE_RATE_ID")
	private Long id;

	@Column(name = "GBP")
	private double GBP;

	@Column(name = "USD")
	private double USD;

	@Column(name = "HKD")
	private double HKD;

	@Temporal(TemporalType.DATE)
	@Column(name = "DATE")
	private Date date;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public double getGBP() {
		return GBP;
	}

	public void setGBP(double gBP) {
		GBP = gBP;
	}

	public double getUSD() {
		return USD;
	}

	public void setUSD(double uSD) {
		USD = uSD;
	}

	public double getHKD() {
		return HKD;
	}

	public void setHKD(double hKD) {
		HKD = hKD;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}
}
