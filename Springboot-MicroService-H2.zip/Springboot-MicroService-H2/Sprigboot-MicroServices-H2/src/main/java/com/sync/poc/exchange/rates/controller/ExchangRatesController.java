package com.sync.poc.exchange.rates.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.AsyncRestTemplate;
import org.springframework.web.client.RestTemplate;

import com.sync.poc.exchange.rates.domain.ExchangeRates;
import com.sync.poc.exchange.rates.exception.ResourceNotFoundException;
import com.sync.poc.exchange.rates.model.ExchangeRatesInfo;
import com.sync.poc.exchange.rates.model.ExchangeRatesType;
import com.sync.poc.exchange.rates.service.ExchangeRatesService;
import com.sync.poc.exchange.rates.transform.ExchangeRatesTransform;
import com.sync.poc.exchange.rates.utils.ExchangeRatesUtil;

@RestController
@RequestMapping("/api/v1")
public class ExchangRatesController {

	@Autowired
	ExchangeRatesService service;

	@PostMapping("/exchangerate")
	public ResponseEntity<List<ExchangeRatesType>> createExchangRates() {
		List<String> dates = ExchangeRatesUtil.getDates();
		List<ExchangeRatesType> result = new ArrayList<>();
		for (String date : dates) {
			Map<String, String> params = new HashMap<String, String>();
			params.put("date", date);
			ResponseEntity<ExchangeRatesInfo> responseEntity = new RestTemplate()
					.getForEntity("https://api.exchangeratesapi.io/{date}", ExchangeRatesInfo.class, params);

			ExchangeRatesInfo exRates = responseEntity.getBody();

			ExchangeRates exchangeRates = ExchangeRatesTransform.getExchangeRates(exRates);
			ExchangeRates exchangeRate = service.createExchangeRates(exchangeRates);
			ExchangeRatesType exchangeRatesType = ExchangeRatesTransform.getExchangeRatesType(exchangeRate);
			result.add(exchangeRatesType);
		}
		return new ResponseEntity<List<ExchangeRatesType>>(result, HttpStatus.CREATED);
	}

	@GetMapping("/exchangerate/{date}/range")
	public ResponseEntity<List<ExchangeRatesType>> getExchangRatesBetweenDates(
			@PathVariable(value = "date") String startDate) throws ResourceNotFoundException {

		List<ExchangeRates> exchangeRates = service.getByDates(startDate);
		if (exchangeRates == null || exchangeRates.isEmpty()) {
			throw new ResourceNotFoundException(
					"No Exchang Rates found in between currentData and startDate:" + startDate);
		}
		List<ExchangeRatesType> result = exchangeRates.stream().map(ExchangeRatesTransform::getExchangeRatesType)
				.collect(Collectors.<ExchangeRatesType>toList());
		return new ResponseEntity<List<ExchangeRatesType>>(result, HttpStatus.OK);
	}

	@GetMapping("/exchangerate/{date}/gbp")
	public ResponseEntity<Map<String, Double>> getGBP(@PathVariable(value = "date") String date)
			throws ResourceNotFoundException {
		ExchangeRates exchangeRates = service.getGPB(date);
		if (exchangeRates == null) {
			throw new ResourceNotFoundException("No Exchang Rates found for this data " + date);
		}

		Map<String, Double> result = new HashMap<>();
		result.put("GBP", exchangeRates.getGBP());
		return new ResponseEntity<Map<String, Double>>(result, HttpStatus.OK);
	}

}
