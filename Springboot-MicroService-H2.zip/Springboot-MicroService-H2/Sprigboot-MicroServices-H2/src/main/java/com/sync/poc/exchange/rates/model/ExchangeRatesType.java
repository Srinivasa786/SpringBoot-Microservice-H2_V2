package com.sync.poc.exchange.rates.model;

import java.util.Date;

public class ExchangeRatesType {
	private Long id;
	
	private double GBP;
	
	private double USD;
	
	private double HKD;
	
	private Date date;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public double getGBP() {
		return GBP;
	}

	public void setGBP(double gBP) {
		GBP = gBP;
	}

	public double getUSD() {
		return USD;
	}

	public void setUSD(double uSD) {
		USD = uSD;
	}

	public double getHKD() {
		return HKD;
	}

	public void setHKD(double hKD) {
		HKD = hKD;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}
}
