package com.sync.poc.exchange.rates.service.impl;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.sync.poc.exchange.rates.domain.ExchangeRates;
import com.sync.poc.exchange.rates.repository.ExchangeRatesRepository;
import com.sync.poc.exchange.rates.service.ExchangeRatesService;

@ExtendWith(MockitoExtension.class)
@RunWith(JUnitPlatform.class)
public class ExchangRatesServiceImplTest {

	@InjectMocks
	ExchangeRatesService exchangRatesService;

	@Mock
	ExchangeRatesRepository exchangeRatesRepository;

	@Test
	public void testCreateExchangeRates() {
		ExchangeRates exchangeRates = new ExchangeRates();
		exchangeRates.setDate(new Date());
		exchangeRates.setGBP(Double.valueOf("10.77"));
		exchangeRates.setHKD(Double.valueOf("10.77"));
		exchangeRates.setId(Long.valueOf(10));
		exchangeRates.setUSD(Double.valueOf("10.77"));

		Mockito.when(exchangeRatesRepository.save(ArgumentMatchers.any())).thenReturn(exchangeRates);
		ExchangeRates result = exchangRatesService.createExchangeRates(exchangeRates);
		assertEquals(Long.valueOf(10), result.getId());
	}

	@Test
	public void testGetByDates() {
		List<ExchangeRates> exchangeRates = new ArrayList<>();
		ExchangeRates exchangeRate = new ExchangeRates();
		exchangeRate.setDate(new Date());
		exchangeRate.setGBP(Double.valueOf("10.77"));
		exchangeRate.setHKD(Double.valueOf("10.77"));
		exchangeRate.setId(Long.valueOf(10));
		exchangeRate.setUSD(Double.valueOf("10.77"));

		Mockito.when(exchangeRatesRepository.findAllByDateBetween(ArgumentMatchers.any(), ArgumentMatchers.any()))
				.thenReturn(exchangeRates);
		List<ExchangeRates> result = exchangRatesService.getByDates("2010-01-30");
		assertNotNull(result);
	}

	@Test
	public void testGetGPB() {
		ExchangeRates exchangeRate = new ExchangeRates();
		exchangeRate.setDate(new Date());
		exchangeRate.setGBP(Double.valueOf("10.77"));
		exchangeRate.setHKD(Double.valueOf("10.77"));
		exchangeRate.setId(Long.valueOf(10));
		exchangeRate.setUSD(Double.valueOf("10.77"));

		Mockito.when(exchangeRatesRepository.findByDate(ArgumentMatchers.any())).thenReturn(exchangeRate);
		ExchangeRates result = exchangRatesService.getGPB("2010-01-30");
		assertNotNull(result);
	}

}
