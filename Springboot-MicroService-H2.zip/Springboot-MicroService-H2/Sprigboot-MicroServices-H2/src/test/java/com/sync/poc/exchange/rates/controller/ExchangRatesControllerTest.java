package com.sync.poc.exchange.rates.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import com.sync.poc.exchange.rates.domain.ExchangeRates;
import com.sync.poc.exchange.rates.exception.ResourceNotFoundException;
import com.sync.poc.exchange.rates.model.ExchangeRatesType;
import com.sync.poc.exchange.rates.service.ExchangeRatesService;

@ExtendWith(MockitoExtension.class)
@RunWith(JUnitPlatform.class)
public class ExchangRatesControllerTest {

	@InjectMocks
	ExchangRatesController exchangRatesController;

	@Mock
	ExchangeRatesService service;

	@Test
	public void testCreateExchangRates() {

		ExchangeRates exchangeRates = new ExchangeRates();
		exchangeRates.setDate(new Date());
		exchangeRates.setGBP(Double.valueOf("10.77"));
		exchangeRates.setHKD(Double.valueOf("10.77"));
		exchangeRates.setId(Long.valueOf(10));
		exchangeRates.setUSD(Double.valueOf("10.77"));
		Mockito.when(service.createExchangeRates(ArgumentMatchers.any())).thenReturn(exchangeRates);
		ResponseEntity<List<ExchangeRatesType>> result = exchangRatesController.createExchangRates();
		assertNotNull(result);
	}

	@Test
	public void testGetExchangRatesBetweenDates() throws ResourceNotFoundException {

		ExchangeRates exchangeRates = new ExchangeRates();
		exchangeRates.setDate(new Date());
		exchangeRates.setGBP(Double.valueOf("10.77"));
		exchangeRates.setHKD(Double.valueOf("10.77"));
		exchangeRates.setId(Long.valueOf(10));
		exchangeRates.setUSD(Double.valueOf("10.77"));
		Mockito.when(service.createExchangeRates(ArgumentMatchers.any())).thenReturn(exchangeRates);
		ResponseEntity<List<ExchangeRatesType>> result = exchangRatesController
				.getExchangRatesBetweenDates("2019-09-01");
		assertNotNull(result);
	}

	@Test
	public void testGetGBP() throws ResourceNotFoundException {

		ExchangeRates exchangeRates = new ExchangeRates();
		exchangeRates.setDate(new Date());
		exchangeRates.setGBP(Double.valueOf("10.77"));
		exchangeRates.setHKD(Double.valueOf("10.77"));
		exchangeRates.setId(Long.valueOf(10));
		exchangeRates.setUSD(Double.valueOf("10.77"));
		Mockito.when(service.getGPB(ArgumentMatchers.any())).thenReturn(exchangeRates);
		ResponseEntity<Map<String, Double>> response = exchangRatesController.getGBP("2019-09-01");
		Map<String, Double> result = response.getBody();
		assertEquals(result.get("GBP"), Double.valueOf("10.77"));
	}

}
